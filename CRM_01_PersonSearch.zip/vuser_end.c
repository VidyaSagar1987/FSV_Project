vuser_end()
{

	CRM_Logout();
	
	return 0;
}
