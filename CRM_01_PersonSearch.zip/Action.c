Action()
{

	int temp;

	lr_start_transaction("CRM_01_PersonSearch_05_Search");

	web_custom_request("dhhs_systemsettings", 
		"URL=https://{param_URL}/api/data/v9.0/roles?$select=name,roleid", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=application/json", 
		"Referer=https://{param_URL}/%7B636557150610000510%7D/WebResources/dhhs_ElasticSearch.html?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&pagemode=iframe&sitemappath=area_service%7cPeople%7cNewSubArea_37de7593", 
		"Snapshot=t221.inf", 
		"EncType=application/json", 
		LAST);
	
/*Correlation comment - Do not change!  Original value='462d2695-18e7-484b-83e9-3af296a53985' Name ='CorrelationParameter_2126' Type ='ResponseBased'*/
	web_reg_save_param_json(
		"ParamName=CorrelationParameter_2128",
		"QueryString=$.value[0].dhhs_azuresearchkey",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_custom_request("dhhs_systemsettings", 
		"URL=https://{param_URL}/api/data/v9.0/dhhs_systemsettings?$select=dhhs_azuresearchkey,dhhs_azuresearchurl,dhhs_d365url,dhhs_hublinkappid", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=application/json", 
		"Referer=https://{param_URL}/%7B636557150610000510%7D/WebResources/dhhs_ElasticSearch.html?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&pagemode=iframe&sitemappath=area_service%7cPeople%7cNewSubArea_37de7593", 
		"Snapshot=t221.inf", 
		"EncType=application/json", 
		LAST);

	web_add_auto_header("Accept", 
		"application/json, text/javascript, */*; q=0.01");

	web_add_auto_header("Accept-Encoding", 
		"gzip, deflate");

	web_add_auto_header("Cache-Control", 
		"no-cache");

	web_add_auto_header("api-key",
		"{CorrelationParameter_2128}");

	web_custom_request("search", 
		"URL={SerachURL}", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{param_URL}/%7B636557150610000510%7D/WebResources/dhhs_ElasticSearch.html?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&pagemode=iframe&sitemappath=area_service%7cPeople%7cNewSubArea_37de7593", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"search\":\"firstname:{param_PersonNumber}\",\"searchFields\":\"lastname\",\"queryType\":\"full\",\"searchMode\":\"all\"}", 
		LAST);

	web_custom_request("search_2", 
		"URL={SerachURL}", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{param_URL}/%7B636557150610000510%7D/WebResources/dhhs_ElasticSearch.html?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&pagemode=iframe&sitemappath=area_service%7cPeople%7cNewSubArea_37de7593", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"search\":\"{param_PersonNumber}~\",\"searchFields\":\"lastname\",\"queryType\":\"full\",\"searchMode\":\"all\"}", 
		LAST);

	web_revert_auto_header("Cache-Control");

	web_revert_auto_header("api-key");

/*Correlation comment - Do not change!  Original value='000d2941-80d3-e711-a845-000d3ad117e3' Name ='oId' Type ='ResponseBased'*/
	web_reg_save_param(
		"oId",
		"LB/IC=contactid\":\"",
		"RB/IC=\",\"dhhs_personidnumber",
		"Ord=All",
		"NotFound=Warning",
		LAST);

	web_add_header("Cache-Control", 
		"no-cache");

	web_add_header("api-key",
		"{CorrelationParameter_2128}");

	web_custom_request("search_3", 
		"URL={SerachURL}", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{param_URL}/%7B636557150610000510%7D/WebResources/dhhs_ElasticSearch.html?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&pagemode=iframe&sitemappath=area_service%7cPeople%7cNewSubArea_37de7593", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"search\":\"/.*{param_PersonNumber}.*/\",\"searchFields\":\"lastname\",\"queryType\":\"full\",\"searchMode\":\"all\"}", 
		LAST);

//lr_output_message("%d",atoi(lr_eval_string("{oId_1}")));


	temp = atoi(lr_eval_string("{oId_count}"));
	
	if(!temp == 0)
			
		{
			lr_end_transaction("CRM_01_PersonSearch_05_Search",LR_PASS);
		}

	else
		{
			lr_output_message("No Search results found for %s",lr_eval_string("{param_PersonNumber}"));
			lr_end_transaction("CRM_01_PersonSearch_05_Search",LR_FAIL);
			return 0;			
		}

	lr_think_time(5);

	web_add_header("Accept", 
		"*/*");

	web_add_auto_header("Accept-Encoding", 
		"gzip, deflate, peerdist");

	web_add_auto_header("Accept-Language", 
		"en-AU");

	web_add_header("LoginRequestCorrelationId", 
		"0961d09b-bd78-4af5-bf95-cc1f97940dd4");

	web_add_auto_header("User-Agent", 
		"Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko");

	web_add_auto_header("X-P2P-PeerDist", 
		"Version=1.1");

	web_add_auto_header("X-P2P-PeerDistEx", 
		"MinContentInformation=1.0, MaxContentInformation=2.0");

/*Correlation comment - Do not change!  Original value='{CorrelationParameter_2127}' Name ='CorrelationParameter_2127' Type ='ResponseBased'*/
	web_reg_save_param_regexp(
		"ParamName=CorrelationParameter_2127",
		"RegExp=REQ_ID:\\ (.*?)\\\r\\\n",
		SEARCH_FILTERS,
		"Scope=Headers",
		"IgnoreRedirections=No",
		LAST);

/*Correlation comment - Do not change!  Original value='{formid}' Name ='formid' Type ='ResponseBased'*/
	web_reg_save_param_json(
		"ParamName=formid",
		"QueryString=$.formData._formId",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

/*Correlation comment - Do not change!  Original value='3149281' Name ='formts' Type ='ResponseBased'*/
	web_reg_save_param_json(
		"ParamName=formts",
		"QueryString=$.formData._version._formVersionNumber",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	web_reg_save_param(
		"CorrelationParameter_2131",
		"LB/IC=\"Token\":\"",
		"RB/IC=\",\"Url\":\"\\/APPWEBSERVICES\\/APPGRIDWEBSERVICE.ASHX\"",
		//"Ord=All",
		//"IgnoreRedirections=No",
		LAST);

/*Correlation comment - Do not change!  Original value='636560669247394188' Name ='CorrelationParameter_2127' Type ='ResponseBased'*/
	web_reg_save_param_json(
		"ParamName=CorrelationParameter_2130",
		"QueryString=$.tokenData[9].Timestamp",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_reg_find("Search=Body",
		"Text={param_PersonNumber}",
		LAST);

	lr_start_transaction("CRM_01_PersonSearch_06_OpenPerson");

	web_url("Data.aspx", 
		"URL=https://{param_URL}/form/Data.aspx?_CreateFromId=&_CreateFromType=&appid=ab18c93f-61e6-e711-a848-000d3ad117e3&counter=1525223431963&etc=2&extraqs=%3fetc%3d2%26id%3d{oId_1}%26process%3d&formid=f869be66-1e6a-4bfc-ae04-37d4659db842&id={oId_1}&oid={oId_1}&pagemode=iframe&pagetype=entityrecord&process=", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/json", 
		"Referer=https://{param_URL}/main.aspx?appid=ab18c93f-61e6-e711-a848-000d3ad117e3", 
		"Snapshot=t257.inf", 
		LAST);

	web_add_header("Accept", 
		"text/html, application/xhtml+xml, */*");

	web_url("ClientApiWrapper.aspx_3",
		"URL=https://{param_URL}/form/ClientApiWrapper.aspx?ver=385312038",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://{param_URL}/form/page.aspx?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&{lcid1}&themeId={themeID}&tstamp={tstamp}&updateTimeStamp={updateTimeStamp}&userts={userts}&ver=385312038",
		"Snapshot=t258.inf",
		"Mode=HTML",
		EXTRARES,
		"URL=../api/data/v9.0/dhhs_alerts?$select=dhhs_alertid,dhhs_enddate,dhhs_name&$filter=_dhhs_personorclient_value%20eq%20{oId_1}%20and%20statecode%20eq%200%20and%20(dhhs_enddate%20eq%20null%20or%20dhhs_enddate%20ge%202018-5-2)", "Referer=https://{param_URL}/form/page.aspx?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&{lcid1}&themeId={themeID}&tstamp={tstamp}&updateTimeStamp={updateTimeStamp}&userts={userts}&ver=385312038", ENDITEM,
		LAST);

	web_revert_auto_header("X-P2P-PeerDist");

	web_revert_auto_header("X-P2P-PeerDistEx");

	web_add_header("SOAPAction", 
		"http://schemas.microsoft.com/crm/2009/WebServices/QuerySipInfo");

	web_add_auto_header("Accept", 
		"*/*");

	web_add_auto_header("Accept-Encoding", 
		"gzip, deflate");

	web_add_auto_header("Cache-Control", 
		"no-cache");

	web_add_auto_header("FormLoadId", 
		"{462ca233-5120-32aa-190e-b393431e31b5}");

	web_add_auto_header("ReferrerReqId",
		"{CorrelationParameter_2127}");

	web_custom_request("PresenceService.asmx_2",
		"URL=https://{param_URL}/AppWebServices/PresenceService.asmx",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=https://{param_URL}/form/page.aspx?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&{lcid1}&themeId={themeID}&tstamp={tstamp}&updateTimeStamp={updateTimeStamp}&userts={userts}&ver=385312038",
		"Snapshot=t259.inf",
		"Mode=HTML",
		"EncType=text/xml; charset=utf-8",
		"Body=<?xml version=\"1.0\" encoding=\"utf-8\" ?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><QuerySipInfo xmlns=\"http://schemas.microsoft.com/crm/2009/WebServices\"><entityListXml>&#60;grid&#62;&#60;row oid&#61;&#34;&#38;&#35;123&#59;560E0EB2-59FC-E711-A843-000D3AD07359&#38;&#35;125&#59;&#34; otype&#61;&#34;8&#34;&#47;&#62;&#60;&#47;grid&#62;</entityListXml></QuerySipInfo></soap:Body></soap:Envelope>",
		LAST);

	web_add_header("SOAPAction", 
		"http://schemas.microsoft.com/crm/2009/WebServices/RetrieveItem");

	web_custom_request("LookupService.asmx_2",
		"URL=https://{param_URL}/AppWebServices/LookupService.asmx",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/xml",
		"Referer=https://{param_URL}/form/page.aspx?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&{lcid1}&themeId={themeID}&tstamp={tstamp}&updateTimeStamp={updateTimeStamp}&userts={userts}&ver=385312038",
		"Snapshot=t260.inf",
		"Mode=HTML",
		"EncType=text/xml; charset=utf-8",
		"Body=<?xml version=\"1.0\" encoding=\"utf-8\" ?><soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"><soap:Body><RetrieveItem xmlns=\"http://schemas.microsoft.com/crm/2009/WebServices\"><typesArray><int>8</int></typesArray><guidValues><string>560e0eb2-59fc-e711-a843-000d3ad07359</string></guidValues><lookupValues></lookupValues><positions></positions><additionalParameters></additionalParameters></RetrieveItem></soap:Body></soap:Envelope>",
		LAST);

	web_revert_auto_header("FormLoadId");

	web_revert_auto_header("ReferrerReqId");

	web_add_auto_header("Accept", 
		"application/xml, text/xml, */*");

	web_add_header("SOAPAction", 
		"http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute");

	web_custom_request("web_2", 
		"URL=https://{param_URL}/XRMServices/2011/Organization.svc/web", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=https://{param_URL}/form/ClientApiWrapper.aspx?ver=385312038", 
		"Snapshot=t261.inf", 
		"Mode=HTML", 
		"EncType=text/xml; charset=utf-8", 
		"Body=<s:Envelope  xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:a=\"http://schemas.microsoft.com/xrm/2011/Contracts\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:b=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\" xmlns:c=\"http://www.w3.org/2001/XMLSchema\" xmlns:d=\"http://schemas.microsoft.com/xrm/2011/Contracts/Services\" xmlns:e=\"http://schemas.microsoft.com/2003/10/Serialization/\" xmlns:f=\"http://schemas.microsoft.com/2003/10/"
		"Serialization/Arrays\" xmlns:g=\"http://schemas.microsoft.com/crm/2011/Contracts\" xmlns:h=\"http://schemas.microsoft.com/xrm/2011/Metadata\" xmlns:j=\"http://schemas.microsoft.com/xrm/2011/Metadata/Query\" xmlns:k=\"http://schemas.microsoft.com/xrm/2013/Metadata\" xmlns:l=\"http://schemas.microsoft.com/xrm/2012/Contracts\"><s:Header><a:SdkClientVersion>6.0</a:SdkClientVersion></s:Header><s:Body><d:Execute><d:request><a:Parameters><a:KeyValuePairOfstringanyType><b:key>Type</b:key><b:value i:type="
		"\"c:int\">1701</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>InputParameter</b:key><b:value i:nil=\"true\" /></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil=\"true\" /><a:RequestName>msdyn_FieldServiceSystemAction</a:RequestName></d:request></d:Execute></s:Body></s:Envelope>", 
		LAST);

	web_add_auto_header("Accept", 
		"*/*");

	web_revert_auto_header("Cache-Control");

	web_add_header("FormLoadId", 
		"{462ca233-5120-32aa-190e-b393431e31b5}");

	web_custom_request("AppGridWebService.ashx_8",
		"URL=https://{param_URL}/AppWebServices/AppGridWebService.ashx?operation=RefreshMulti",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://{param_URL}/form/page.aspx?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&{lcid1}&themeId={themeID}&tstamp={tstamp}&updateTimeStamp={updateTimeStamp}&userts={userts}&ver=385312038",
		"Snapshot=t262.inf",
		"Mode=HTML",
		"EncType=text/plain;charset=UTF-8",
		"Body=<gridMultiRequest><gridRequest id=\"subgrid_screening_person\"><grid><sortColumns>dhhs_screening&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>10</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>1</max><refreshAsync>True</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><returntotalrecordcount>True</returntotalrecordcount><getParameters>getFetchXmlForFilters</getParameters><parameters><viewid>&#123;F6D0AA06-3DC4-E711-816B-E0071B675C91&#125;</viewid><autorefresh>1</autorefresh><isGridHidden>false</isGridHidden><LayoutStyle>LiteGridList</LayoutStyle><maxselectableitems>1</maxselectableitems><isGridFilteringEnabled>1</isGridFilteringEnabled><viewtype>1039</viewtype><viewts>4797721</viewts><RecordsPerPage>10</RecordsPerP"
		"age><viewTitle>Person Personal Screening View</viewTitle><layoutXml>&#60;grid name&#61;&#34;resultset&#34; jump&#61;&#34;dhhs_name&#34; select&#61;&#34;1&#34; preview&#61;&#34;1&#34; icon&#61;&#34;1&#34; object&#61;&#34;10249&#34;&#62;&#60;row name&#61;&#34;result&#34; id&#61;&#34;dhhs_screeningpersonsid&#34;&#62;&#60;cell name&#61;&#34;dhhs_screening&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;a_a79cc2c4c1a7e7118148e0071b6d9931.createdon&#34; width&#61;&#34;200&#34; disableSorting&#61;&#34;1&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; relatedentityname&#61;&#34;dhhs_screening&#34; relatedentityattr&#61;&#34;dhhs_screeningid&#34; primaryentityattr&#61;&#34;dhhs_screening&#34; relationshipid&#61;&#34;&#123;1b2060c5-8216-4c89-8859-64ac83c9692e&#125;&#34; relationshipname&#61;&#34;dhhs_screening_dhhs_screeningpersons&#34; &#47;&#"
		"62;&#60;cell name&#61;&#34;a_a79cc2c4c1a7e7118148e0071b6d9931.dhhs_contacttype&#34; width&#61;&#34;200&#34; disableSorting&#61;&#34;1&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; relatedentityname&#61;&#34;dhhs_screening&#34; relatedentityattr&#61;&#34;dhhs_screeningid&#34; primaryentityattr&#61;&#34;dhhs_screening&#34; relationshipid&#61;&#34;&#123;1b2060c5-8216-4c89-8859-64ac83c9692e&#125;&#34; relationshipname&#61;&#34;dhhs_screening_dhhs_screeningpersons&#34; &#47;&#62;&#60;cell name&#61;&#34;a_a79cc2c4c1a7e7118148e0071b6d9931.statecode&#34; width&#61;&#34;200&#34; disableSorting&#61;&#34;1&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; relatedentityname&#61;&#34;dhhs_screening&#34; relatedentityattr&#61;&#34;dhhs_screeningid&#34; primaryentityattr&#61;&#34;dhhs_screening&#34; relationshipid&#61;&#34;&#123;1b2060c5-8216-4c89-8859-64ac83c9692e&#125;&#34; relationshipname&#61;&#34;dhhs"
		"_screening_dhhs_screeningpersons&#34; &#47;&#62;&#60;&#47;row&#62;&#60;&#47;grid&#62;</layoutXml><otc>10249</otc><otn>dhhs_screeningpersons</otn><entitydisplayname>Screening person</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Screening persons</entitypluraldisplayname><expandable>1</expandable><showjumpbar>0</showjumpbar><maxrowsbeforescroll>12</maxrowsbeforescroll><tabindex>1250</tabindex><refreshasynchronous>1</refreshasynchronous><subgridAutoExpand>0</subgridAutoExpand><relName>dhhs_contact_dhhs_screeningpersons</relName><roleOrd>-1</roleOrd><oType></oType><relationshipType>1</relationshipType><ribbonContext>SubGridStandard</ribbonContext><GridType>SubGrid</GridType><enableContextualActions>true</enableContextualActions><teamTemplateId></teamTemplateId><isWorkflowSupported>true</isWorkflowSupported><LoadOnDemand_GridEmptyMessage>To load &#123;0&#125; records, click here.</LoadOnDemand_GridEmptyMessage><enableFilters></enableFilters><RenderAsync>0</Rend"
		"erAsync><oId>{oId_1}</oId><oType>2</oType><isTurboForm>1</isTurboForm></parameters><columns><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Screening&#32;Ref&#32;number\" fieldname=\"dhhs_screening\" entityname=\"dhhs_screeningpersons\">dhhs_screening</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Created&#32;On&#32;&#40;Screening&#32;Ref&#32;number&#41;\" fieldname=\"createdon\" entityname=\"dhhs_screening\" relationshipname=\"dhhs_screening_dhhs_screeningpersons\">a_a79cc2c4c1a7e7118148e0071b6d9931.createdon</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Contact&#32;type&#32;&#40;Screening&#32;Ref&#32;number&#41;\" fieldname=\"dhhs_contacttype\" entityname=\"dhhs_screening\" relationshipname=\"dhhs_screening_dhhs_screeningpersons\">a_a79cc2c4c1a7e7118148e0071b6d9931.dhhs_contacttype</column><column width=\"200\" isHidden=\""
		"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Status&#32;&#40;Screening&#32;Ref&#32;number&#41;\" fieldname=\"statecode\" entityname=\"dhhs_screening\" relationshipname=\"dhhs_screening_dhhs_screeningpersons\">a_a79cc2c4c1a7e7118148e0071b6d9931.statecode</column></columns></grid></gridRequest><gridRequest id=\"InvolvementInOtherCasesNew\"><grid><sortColumns>record2id&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>10</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>1</max><refreshAsync>True</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><returntotalrecordcount>True</returntotalrecordcount><getParameters>getFetchXmlForFilters</getParameters><parameters><viewid>&#123;4912834B-4506-E811-A829-000D3AE0C995&#12"
		"5;</viewid><autorefresh>1</autorefresh><isGridHidden>false</isGridHidden><LayoutStyle>LiteGridList</LayoutStyle><maxselectableitems>1</maxselectableitems><isGridFilteringEnabled>1</isGridFilteringEnabled><viewtype>1039</viewtype><viewts>4796575</viewts><RecordsPerPage>10</RecordsPerPage><viewTitle>Connection - Involvement in other cases - Case Title</viewTitle><layoutXml>&#60;grid name&#61;&#34;resultset&#34; jump&#61;&#34;name&#34; select&#61;&#34;1&#34; preview&#61;&#34;1&#34; icon&#61;&#34;1&#34; object&#61;&#34;3234&#34;&#62;&#60;row name&#61;&#34;result&#34; id&#61;&#34;connectionid&#34;&#62;&#60;cell name&#61;&#34;record2id&#34; width&#61;&#34;300&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;&#47;row&#62;&#60;&#47;grid&#62;</layoutXml><otc>3234</otc><otn>connection</otn><entitydisplayname>Connection</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Connections</entitypluraldispl"
		"ayname><expandable>1</expandable><showjumpbar>0</showjumpbar><maxrowsbeforescroll>12</maxrowsbeforescroll><tabindex>1260</tabindex><refreshasynchronous>1</refreshasynchronous><subgridAutoExpand>0</subgridAutoExpand><relName>contact_connections1</relName><roleOrd>-1</roleOrd><oType></oType><relationshipType>1</relationshipType><ribbonContext>SubGridStandard</ribbonContext><GridType>SubGrid</GridType><enableContextualActions>true</enableContextualActions><teamTemplateId></teamTemplateId><isWorkflowSupported>true</isWorkflowSupported><LoadOnDemand_GridEmptyMessage>To load &#123;0&#125; records, click here.</LoadOnDemand_GridEmptyMessage><enableFilters></enableFilters><RenderAsync>0</RenderAsync><oId>{oId_1}</oId><oType>2</oType><isTurboForm>1</isTurboForm></parameters><columns><column width=\"300\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Connected&#32;to\" fieldname=\"record2id\" entityname=\"connection\">record2id</column></columns></grid></gridRequ"
		"est><gridRequest id=\"Other_engagement\"><grid><sortColumns>createdon&#58;0&#59;dhhs_subject&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>10</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>1</max><refreshAsync>True</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><returntotalrecordcount>True</returntotalrecordcount><getParameters>getFetchXmlForFilters</getParameters><parameters><viewid>&#123;C8A7D24A-932C-E811-A832-000D3AE09197&#125;</viewid><autorefresh>1</autorefresh><isGridHidden>false</isGridHidden><LayoutStyle>LiteGridList</LayoutStyle><maxselectableitems>1</maxselectableitems><isGridFilteringEnabled>1</isGridFilteringEnabled><viewtype>1039</viewtype><viewts>4796770</viewts><RecordsPerPage>10</RecordsPerPage><vie"
		"wTitle>CaseActivities_For_Personal_Person</viewTitle><layoutXml>&#60;grid name&#61;&#34;resultset&#34; jump&#61;&#34;dhhs_name&#34; select&#61;&#34;1&#34; icon&#61;&#34;1&#34; preview&#61;&#34;1&#34; object&#61;&#34;10216&#34;&#62;&#60;row name&#61;&#34;result&#34; id&#61;&#34;dhhs_caseactivityid&#34;&#62;&#60;cell name&#61;&#34;dhhs_activitylink&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_category&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;createdon&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_actualstart&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_activitytype&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_subject&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageprovide"
		"rwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;ownerid&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_statusreasontext&#34; width&#61;&#34;125&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;&#47;row&#62;&#60;&#47;grid&#62;</layoutXml><otc>10216</otc><otn>dhhs_caseactivity</otn><entitydisplayname>Case Activity</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Case Activities</entitypluraldisplayname><expandable>1</expandable><showjumpbar>0</showjumpbar><maxrowsbeforescroll>12</maxrowsbeforescroll><tabindex>1270</tabindex><refreshasynchronous>1</refreshasynchronous><subgridAutoExpand>0</subgridAutoExpand><relName>dhhs_contact_dhhs_caseactivity_PersonId</relName><roleOrd>-1</roleOrd><oType></oType><relationshipType>1</relationshipType><ribbonContext>SubGridStandard</ribbonContext><GridType>SubGrid</GridType><enableContextualActions>t"
		"rue</enableContextualActions><teamTemplateId></teamTemplateId><isWorkflowSupported>true</isWorkflowSupported><LoadOnDemand_GridEmptyMessage>To load &#123;0&#125; records, click here.</LoadOnDemand_GridEmptyMessage><enableFilters></enableFilters><RenderAsync>0</RenderAsync><oId>{oId_1}</oId><oType>2</oType><isTurboForm>1</isTurboForm></parameters><columns><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;link\" fieldname=\"dhhs_activitylink\" entityname=\"dhhs_caseactivity\">dhhs_activitylink</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Category\" fieldname=\"dhhs_category\" entityname=\"dhhs_caseactivity\">dhhs_category</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Created&#32;On\" fieldname=\"createdon\" entityname=\"dhhs_caseactivity\">createdon</column><column width=\"150\" isHidden=\"false\" isMetadataBound="
		"\"true\" isSortable=\"true\" label=\"Actual&#32;start\" fieldname=\"dhhs_actualstart\" entityname=\"dhhs_caseactivity\">dhhs_actualstart</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;type\" fieldname=\"dhhs_activitytype\" entityname=\"dhhs_caseactivity\">dhhs_activitytype</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Subject\" fieldname=\"dhhs_subject\" entityname=\"dhhs_caseactivity\">dhhs_subject</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Owner\" fieldname=\"ownerid\" entityname=\"dhhs_caseactivity\">ownerid</column><column width=\"125\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;status\" fieldname=\"dhhs_statusreasontext\" entityname=\"dhhs_caseactivity\">dhhs_statusreasontext</column></columns></grid></gridRequest><gridRequest id=\"case_personal\"><grid><sortColumns>title&#58;1</so"
		"rtColumns><pageNum>1</pageNum><recsPerPage>10</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>1</max><refreshAsync>True</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><returntotalrecordcount>True</returntotalrecordcount><getParameters>getFetchXmlForFilters</getParameters><parameters><viewid>&#123;43C745C5-31C4-E711-816B-E0071B675C91&#125;</viewid><autorefresh>1</autorefresh><isGridHidden>false</isGridHidden><LayoutStyle>LiteGridList</LayoutStyle><maxselectableitems>1</maxselectableitems><isGridFilteringEnabled>1</isGridFilteringEnabled><viewtype>1039</viewtype><viewts>4797984</viewts><RecordsPerPage>10</RecordsPerPage><viewTitle>Person Personal Case Subgrid</viewTitle><layoutXml>&#60;grid name&#61;&#34;resultset&#34; jump&"
		"#61;&#34;title&#34; select&#61;&#34;1&#34; preview&#61;&#34;1&#34; icon&#61;&#34;1&#34; object&#61;&#34;112&#34;&#62;&#60;row name&#61;&#34;result&#34; id&#61;&#34;incidentid&#34;&#62;&#60;cell name&#61;&#34;ticketnumber&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;title&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;createdon&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;statuscode&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;a_e653b5d56ebfe711814ce0071b6d9931.dhhs_name&#34; width&#61;&#34;125&#34; disableSorting&#61;&#34;1&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; relateden"
		"tityname&#61;&#34;dhhs_casegroup&#34; relatedentityattr&#61;&#34;dhhs_casegroupid&#34; primaryentityattr&#61;&#34;dhhs_casegroupsid&#34; relationshipid&#61;&#34;&#123;c74718a9-9cf5-41a1-a23d-6715d8f522e1&#125;&#34; relationshipname&#61;&#34;dhhs_casegroup_incident_Casegroupsid&#34; &#47;&#62;&#60;cell name&#61;&#34;ownerid&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;&#47;row&#62;&#60;&#47;grid&#62;</layoutXml><otc>112</otc><otn>incident</otn><entitydisplayname>Case</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Cases</entitypluraldisplayname><expandable>1</expandable><showjumpbar>0</showjumpbar><maxrowsbeforescroll>12</maxrowsbeforescroll><tabindex>1280</tabindex><refreshasynchronous>1</refreshasynchronous><subgridAutoExpand>0</subgridAutoExpand><relName>incident_customer_contacts</relName><roleOrd>-1</roleOrd><oType></oType><relationshipType>1</relationshipType><ribbonContext>SubGridStandard</ribbonContext><GridType>SubGrid</GridType><enableContextualActio"
		"ns>true</enableContextualActions><teamTemplateId></teamTemplateId><isWorkflowSupported>true</isWorkflowSupported><LoadOnDemand_GridEmptyMessage>To load &#123;0&#125; records, click here.</LoadOnDemand_GridEmptyMessage><enableFilters></enableFilters><RenderAsync>0</RenderAsync><oId>{oId_1}</oId><oType>2</oType><isTurboForm>1</isTurboForm></parameters><columns><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Case&#32;ID\" fieldname=\"ticketnumber\" entityname=\"incident\">ticketnumber</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Case&#32;title\" fieldname=\"title\" entityname=\"incident\" renderertype=\"Crm.PrimaryField\">title</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Created&#32;on\" fieldname=\"createdon\" entityname=\"incident\">createdon</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSort"
		"able=\"true\" label=\"Status\" fieldname=\"statuscode\" entityname=\"incident\">statuscode</column><column width=\"125\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Name&#32;&#40;Case&#32;groups&#41;\" fieldname=\"dhhs_name\" entityname=\"dhhs_casegroup\" relationshipname=\"dhhs_casegroup_incident_Casegroupsid\">a_e653b5d56ebfe711814ce0071b6d9931.dhhs_name</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Owner\" fieldname=\"ownerid\" entityname=\"incident\">ownerid</column></columns></grid></gridRequest><gridRequest id=\"PersonalConnections\"><grid><sortColumns>record2roleid&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>10</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>1</max><refreshAsync>True</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingW"
		"henOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><returntotalrecordcount>True</returntotalrecordcount><getParameters>getFetchXmlForFilters</getParameters><parameters><viewid>&#123;95FA8C2A-15D0-E711-A826-000D3AE0A6CF&#125;</viewid><autorefresh>1</autorefresh><isGridHidden>false</isGridHidden><LayoutStyle>LiteGridList</LayoutStyle><maxselectableitems>1</maxselectableitems><isGridFilteringEnabled>1</isGridFilteringEnabled><viewtype>1039</viewtype><viewts>4796581</viewts><RecordsPerPage>10</RecordsPerPage><viewTitle>Connection - Personal Connections on Personal</viewTitle><layoutXml>&#60;grid name&#61;&#34;resultset&#34; jump&#61;&#34;name&#34; select&#61;&#34;1&#34; preview&#61;&#34;1&#34; icon&#61;&#34;1&#34; object&#61;&#34;3234&#34;&#62;&#60;row id&#61;&#34;connectionid&#34; name&#61;&#34;result&#34;&#62;&#60;cell name&#61;&#34;record2roleid&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;"
		"webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;record2id&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_liveswithperson&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_source_ofsupport&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_accesscustodydetails&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;effectivestart&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;effectiveend&#34; width&#61;&#34;200&#34; image"
		"providerfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;&#47;row&#62;&#60;&#47;grid&#62;</layoutXml><otc>3234</otc><otn>connection</otn><entitydisplayname>Connection</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Connections</entitypluraldisplayname><expandable>1</expandable><showjumpbar>0</showjumpbar><maxrowsbeforescroll>12</maxrowsbeforescroll><tabindex>2360</tabindex><refreshasynchronous>1</refreshasynchronous><subgridAutoExpand>0</subgridAutoExpand><relName>contact_connections1</relName><roleOrd>-1</roleOrd><oType></oType><relationshipType>1</relationshipType><ribbonContext>SubGridStandard</ribbonContext><GridType>SubGrid</GridType><enableContextualActions>true</enableContextualActions><teamTemplateId></teamTemplateId><isWorkflowSupported>true</isWorkflowSupported><LoadOnDemand_GridEmptyMessage>To load &#123;0&#125; records, click here.</LoadOnDemand_GridEmptyMessage><enableFilters></enableFilters"
		"><RenderAsync>0</RenderAsync><oId>{oId_1}</oId><oType>2</oType><isTurboForm>1</isTurboForm></parameters><columns><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Role&#32;&#40;To&#41;\" fieldname=\"record2roleid\" entityname=\"connection\">record2roleid</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Connected&#32;to\" fieldname=\"record2id\" entityname=\"connection\">record2id</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Lives&#32;with&#32;person\" fieldname=\"dhhs_liveswithperson\" entityname=\"connection\">dhhs_liveswithperson</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Source&#32;of&#32;support\" fieldname=\"dhhs_source_ofsupport\" entityname=\"connection\">dhhs_source_ofsupport</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\""
		"true\" label=\"Access&#47;Custody&#32;details\" fieldname=\"dhhs_accesscustodydetails\" entityname=\"connection\">dhhs_accesscustodydetails</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Start&#32;date\" fieldname=\"effectivestart\" entityname=\"connection\">effectivestart</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"End&#32;date\" fieldname=\"effectiveend\" entityname=\"connection\">effectiveend</column></columns></grid></gridRequest><gridRequest id=\"OrganisationsEmployee\"><grid><sortColumns>dhhs_directemail&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>10</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>1</max><refreshAsync>True</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenO"
		"nePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><returntotalrecordcount>True</returntotalrecordcount><getParameters>getFetchXmlForFilters</getParameters><parameters><viewid>&#123;6EC0A772-3806-E811-A829-000D3AE0C995&#125;</viewid><autorefresh>1</autorefresh><isGridHidden>false</isGridHidden><LayoutStyle>LiteGridList</LayoutStyle><maxselectableitems>1</maxselectableitems><isGridFilteringEnabled>1</isGridFilteringEnabled><viewtype>1039</viewtype><viewts>4797034</viewts><RecordsPerPage>10</RecordsPerPage><viewTitle>Employees on Professional person form</viewTitle><layoutXml>&#60;grid name&#61;&#34;resultset&#34; jump&#61;&#34;dhhs_name&#34; select&#61;&#34;1&#34; preview&#61;&#34;1&#34; icon&#61;&#34;1&#34; object&#61;&#34;10226&#34;&#62;&#60;row name&#61;&#34;result&#34; id&#61;&#34;dhhs_employeeid&#34;&#62;&#60;cell name&#61;&#34;dhhs_accountid&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;"
		"&#60;cell name&#61;&#34;a_ec0c5abd4ecfe711a826000d3ae0a7f8.address1_city&#34; width&#61;&#34;200&#34; disableSorting&#61;&#34;1&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; relatedentityname&#61;&#34;account&#34; relatedentityattr&#61;&#34;accountid&#34; primaryentityattr&#61;&#34;dhhs_accountid&#34; relationshipid&#61;&#34;&#123;d8fde471-3bcf-4f16-84b1-69f4c5a08192&#125;&#34; relationshipname&#61;&#34;dhhs_account_dhhs_employee_Accountid&#34; &#47;&#62;&#60;cell name&#61;&#34;a_ec0c5abd4ecfe711a826000d3ae0a7f8.telephone1&#34; width&#61;&#34;200&#34; disableSorting&#61;&#34;1&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; relatedentityname&#61;&#34;account&#34; relatedentityattr&#61;&#34;accountid&#34; primaryentityattr&#61;&#34;dhhs_accountid&#34; relationshipid&#61;&#34;&#123;d8fde471-3bcf-4f16-84b1-69f4c5a08192&#125;&#34; relationshipname&#61;&#34;dhhs_account_dhhs_employee_Accountid&"
		"#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_role&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_direct_phone&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_directemail&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_employmentstatus&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;&#47;row&#62;&#60;&#47;grid&#62;</layoutXml><otc>10226</otc><otn>dhhs_employee</otn><entitydisplayname>Employee</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Employees</entitypluraldisplayname><expandable>1</expandable><showjumpbar>0</showjumpbar><maxrowsbeforescroll>12</maxrowsbeforescroll><tabindex>2630</tabindex><refresh"
		"asynchronous>1</refreshasynchronous><subgridAutoExpand>0</subgridAutoExpand><relName>dhhs_contact_dhhs_employee_Employeename</relName><roleOrd>-1</roleOrd><oType></oType><relationshipType>1</relationshipType><ribbonContext>SubGridStandard</ribbonContext><GridType>SubGrid</GridType><enableContextualActions>true</enableContextualActions><teamTemplateId></teamTemplateId><isWorkflowSupported>true</isWorkflowSupported><LoadOnDemand_GridEmptyMessage>To load &#123;0&#125; records, click here.</LoadOnDemand_GridEmptyMessage><enableFilters></enableFilters><RenderAsync>0</RenderAsync><oId>{oId_1}</oId><oType>2</oType><isTurboForm>1</isTurboForm></parameters><columns><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Organisation\" fieldname=\"dhhs_accountid\" entityname=\"dhhs_employee\">dhhs_accountid</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Address&#32;&#58;&#32;City&#32;&#40;Organisa"
		"tion&#41;\" fieldname=\"address1_city\" entityname=\"account\" relationshipname=\"dhhs_account_dhhs_employee_Accountid\">a_ec0c5abd4ecfe711a826000d3ae0a7f8.address1_city</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Phone&#32;number&#32;&#40;Organisation&#41;\" fieldname=\"telephone1\" entityname=\"account\" relationshipname=\"dhhs_account_dhhs_employee_Accountid\">a_ec0c5abd4ecfe711a826000d3ae0a7f8.telephone1</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Role\" fieldname=\"dhhs_role\" entityname=\"dhhs_employee\">dhhs_role</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Direct&#32;phone\" fieldname=\"dhhs_direct_phone\" entityname=\"dhhs_employee\">dhhs_direct_phone</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Direct&#32;email\" fieldname=\"dhhs_directemail\" entityname=\"dhhs_employee\""
		">dhhs_directemail</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Employment&#32;status\" fieldname=\"dhhs_employmentstatus\" entityname=\"dhhs_employee\">dhhs_employmentstatus</column></columns></grid></gridRequest><gridRequest id=\"ActivitiesProfessional\"><grid><sortColumns>createdon&#58;0&#59;dhhs_subject&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>10</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>1</max><refreshAsync>True</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><returntotalrecordcount>True</returntotalrecordcount><getParameters>getFetchXmlForFilters</getParameters><parameters><viewid>&#123;A0F0F688-932C-E811-A832-000D3AE09197&#125;</viewid><autorefr"
		"esh>1</autorefresh><isGridHidden>false</isGridHidden><LayoutStyle>LiteGridList</LayoutStyle><maxselectableitems>1</maxselectableitems><isGridFilteringEnabled>1</isGridFilteringEnabled><viewtype>1039</viewtype><viewts>4796774</viewts><RecordsPerPage>10</RecordsPerPage><viewTitle>CaseActivities_For_Professional_Person</viewTitle><layoutXml>&#60;grid name&#61;&#34;resultset&#34; jump&#61;&#34;dhhs_name&#34; select&#61;&#34;1&#34; icon&#61;&#34;1&#34; preview&#61;&#34;1&#34; object&#61;&#34;10216&#34;&#62;&#60;row name&#61;&#34;result&#34; id&#61;&#34;dhhs_caseactivityid&#34;&#62;&#60;cell name&#61;&#34;dhhs_activitylink&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_category&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;createdon&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_actualstart&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&"
		"#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_activitytype&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_subject&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;ownerid&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_statusreasontext&#34; width&#61;&#34;125&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;&#47;row&#62;&#60;&#47;grid&#62;</layoutXml><otc>10216</otc><otn>dhhs_caseactivity</otn><entitydisplayname>Case Activity</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Case Activities</entitypluraldisplayname><expandable>1</expandable><showjumpbar>0</showjumpbar><maxrowsbeforescroll>12</maxrowsbeforescroll><tabindex>2650</tabindex><refreshasynchronous>1</refreshasynchron"
		"ous><subgridAutoExpand>0</subgridAutoExpand><relName>dhhs_contact_dhhs_caseactivity_PersonId</relName><roleOrd>-1</roleOrd><oType></oType><relationshipType>1</relationshipType><ribbonContext>SubGridStandard</ribbonContext><GridType>SubGrid</GridType><enableContextualActions>true</enableContextualActions><teamTemplateId></teamTemplateId><isWorkflowSupported>true</isWorkflowSupported><LoadOnDemand_GridEmptyMessage>To load &#123;0&#125; records, click here.</LoadOnDemand_GridEmptyMessage><enableFilters></enableFilters><RenderAsync>0</RenderAsync><oId>{oId_1}</oId><oType>2</oType><isTurboForm>1</isTurboForm></parameters><columns><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;link\" fieldname=\"dhhs_activitylink\" entityname=\"dhhs_caseactivity\">dhhs_activitylink</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Category\" fieldname=\"dhhs_category\" entityname=\"dhhs_case"
		"activity\">dhhs_category</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Created&#32;On\" fieldname=\"createdon\" entityname=\"dhhs_caseactivity\">createdon</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Actual&#32;start\" fieldname=\"dhhs_actualstart\" entityname=\"dhhs_caseactivity\">dhhs_actualstart</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;type\" fieldname=\"dhhs_activitytype\" entityname=\"dhhs_caseactivity\">dhhs_activitytype</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Subject\" fieldname=\"dhhs_subject\" entityname=\"dhhs_caseactivity\">dhhs_subject</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Owner\" fieldname=\"ownerid\" entityname=\"dhhs_caseactivity\">ownerid</column><column width=\"125\" isHidden=\"false"
		"\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;status\" fieldname=\"dhhs_statusreasontext\" entityname=\"dhhs_caseactivity\">dhhs_statusreasontext</column></columns></grid></gridRequest><gridRequest id=\"AlertsOnPerson\"><grid><sortColumns>dhhs_name&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>10</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>1</max><refreshAsync>True</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><returntotalrecordcount>True</returntotalrecordcount><getParameters>getFetchXmlForFilters</getParameters><parameters><viewid>&#123;BB5AB034-29D3-E711-A825-000D3AE0CB84&#125;</viewid><autorefresh>1</autorefresh><isGridHidden>false</isGridHidden><LayoutStyle>LiteGridList</LayoutStyle><"
		"maxselectableitems>1</maxselectableitems><isGridFilteringEnabled>1</isGridFilteringEnabled><viewtype>1039</viewtype><viewts>4796707</viewts><RecordsPerPage>10</RecordsPerPage><viewTitle>Alerts on Person</viewTitle><layoutXml>&#60;grid name&#61;&#34;resultset&#34; jump&#61;&#34;dhhs_name&#34; select&#61;&#34;1&#34; preview&#61;&#34;1&#34; icon&#61;&#34;1&#34; object&#61;&#34;10213&#34;&#62;&#60;row name&#61;&#34;result&#34; id&#61;&#34;dhhs_alertid&#34;&#62;&#60;cell name&#61;&#34;createdon&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_name&#34; width&#61;&#34;300&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_type&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_enddate"
		"&#34; width&#61;&#34;125&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;statuscode&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;ownerid&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;&#47;row&#62;&#60;&#47;grid&#62;</layoutXml><otc>10213</otc><otn>dhhs_alert</otn><entitydisplayname>Alert</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Alerts</entitypluraldisplayname><expandable>1</expandable><showjumpbar>0</showjumpbar><maxrowsbeforescroll>12</maxrowsbeforescroll><tabindex>2670</tabindex><refreshasynchronous>1</refreshasynchronous><subgridAutoExpand>0</subgridAutoExpand><relName>dhhs_contact_dhhs_alert_PersonorClient</relName><roleOrd>-1</roleOrd><oType></oType><relationshipType>1</relationshipType><ribbonContext>SubGridStandard</ribbonContext><GridTy"
		"pe>SubGrid</GridType><enableContextualActions>true</enableContextualActions><teamTemplateId></teamTemplateId><isWorkflowSupported>true</isWorkflowSupported><LoadOnDemand_GridEmptyMessage>To load &#123;0&#125; records, click here.</LoadOnDemand_GridEmptyMessage><enableFilters></enableFilters><RenderAsync>0</RenderAsync><oId>{oId_1}</oId><oType>2</oType><isTurboForm>1</isTurboForm></parameters><columns><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Created&#32;on\" fieldname=\"createdon\" entityname=\"dhhs_alert\">createdon</column><column width=\"300\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Subject\" fieldname=\"dhhs_name\" entityname=\"dhhs_alert\" renderertype=\"Crm.PrimaryField\">dhhs_name</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Type\" fieldname=\"dhhs_type\" entityname=\"dhhs_alert\">dhhs_type</column><column width=\"125\" isHidden=\"fa"
		"lse\" isMetadataBound=\"true\" isSortable=\"true\" label=\"End&#32;date\" fieldname=\"dhhs_enddate\" entityname=\"dhhs_alert\">dhhs_enddate</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Status\" fieldname=\"statuscode\" entityname=\"dhhs_alert\">statuscode</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Owner\" fieldname=\"ownerid\" entityname=\"dhhs_alert\">ownerid</column></columns></grid></gridRequest><gridRequest id=\"subgrid_activities\"><grid><sortColumns>scheduledend&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>4</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>1</max><refreshAsync>True</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1<"
		"/refreshCalledFromRefreshButton><returntotalrecordcount>True</returntotalrecordcount><getParameters>getFetchXmlForFilters</getParameters><parameters><viewid>&#123;00000000-0000-0000-00AA-000010001902&#125;</viewid><autorefresh>1</autorefresh><isGridHidden>false</isGridHidden><LayoutStyle>LiteGridList</LayoutStyle><maxselectableitems>1</maxselectableitems><isGridFilteringEnabled>1</isGridFilteringEnabled><viewtype>1039</viewtype><viewts>4796528</viewts><RecordsPerPage>4</RecordsPerPage><viewTitle>All Activities</viewTitle><layoutXml>&#60;grid name&#61;&#34;resultset&#34; jump&#61;&#34;subject&#34; select&#61;&#34;1&#34; preview&#61;&#34;1&#34; icon&#61;&#34;1&#34; object&#61;&#34;4200&#34;&#62;&#60;row name&#61;&#34;result&#34; id&#61;&#34;activityid&#34; multiobjectidfield&#61;&#34;activitytypecode&#34;&#62;&#60;cell name&#61;&#34;subject&#34; width&#61;&#34;180&#34; &#47;&#62;&#60;cell name&#61;&#34;regardingobjectid&#34; width&#61;&#34;110&#34; &#47;&#62;&#60;cell name&#61;&#34;activitytypecode&#34; width"
		"&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;statecode&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;ownerid&#34; width&#61;&#34;120&#34; &#47;&#62;&#60;cell name&#61;&#34;prioritycode&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;scheduledstart&#34; width&#61;&#34;140&#34; &#47;&#62;&#60;cell name&#61;&#34;scheduledend&#34; width&#61;&#34;140&#34; &#47;&#62;&#60;cell name&#61;&#34;activitypointerowningusersystemusersystemuserid.internalemailaddress&#34; width&#61;&#34;100&#34; disableSorting&#61;&#34;1&#34; relatedentityname&#61;&#34;systemuser&#34; relatedentityattr&#61;&#34;systemuserid&#34; primaryentityattr&#61;&#34;owninguser&#34; relationshipid&#61;&#34;&#123;f741d22b-7cad-4b9d-a491-4f22de63ac65&#125;&#34; relationshipname&#61;&#34;user_activity&#34; &#47;&#62;&#60;cell name&#61;&#34;createdon&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;instancetypecode&#34; width&#61;&#34;100&#34; ishidden&#61;&#34;1&#34; &#47;&#62;&#60;cell name&#61;&#34;"
		"community&#34; width&#61;&#34;100&#34; ishidden&#61;&#34;1&#34; &#47;&#62;&#60;&#47;row&#62;&#60;&#47;grid&#62;</layoutXml><otc>4200</otc><otn>activitypointer</otn><entitydisplayname>Activity</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Activities</entitypluraldisplayname><expandable>1</expandable><showjumpbar>0</showjumpbar><maxrowsbeforescroll>6</maxrowsbeforescroll><tabindex>2690</tabindex><refreshasynchronous>1</refreshasynchronous><subgridAutoExpand>0</subgridAutoExpand><relName>Contact_ActivityPointers</relName><roleOrd>-1</roleOrd><oType>2</oType><relationshipType>1</relationshipType><ribbonContext>SubGridStandard</ribbonContext><GridType>SubGrid</GridType><enableContextualActions>true</enableContextualActions><teamTemplateId></teamTemplateId><isWorkflowSupported>true</isWorkflowSupported><LoadOnDemand_GridEmptyMessage>To load &#123;0&#125; records, click here.</LoadOnDemand_GridEmptyMessage><enableFilters></enableFilters><InnerGridDisabled>0</Inne"
		"rGridDisabled><oId>&#123;{oId_1}&#125;</oId><RenderAsync>0</RenderAsync><oId>{oId_1}</oId><oType>2</oType><isTurboForm>1</isTurboForm></parameters><columns><column width=\"180\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Subject\" fieldname=\"subject\" entityname=\"activitypointer\" renderertype=\"Crm.PrimaryField\">subject</column><column width=\"110\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Regarding\" fieldname=\"regardingobjectid\" entityname=\"activitypointer\">regardingobjectid</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;Type\" fieldname=\"activitytypecode\" entityname=\"activitypointer\">activitytypecode</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;Status\" fieldname=\"statecode\" entityname=\"activitypointer\">statecode</column><column width=\""
		"120\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Owner\" fieldname=\"ownerid\" entityname=\"activitypointer\">ownerid</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Priority\" fieldname=\"prioritycode\" entityname=\"activitypointer\">prioritycode</column><column width=\"140\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Start&#32;Date\" fieldname=\"scheduledstart\" entityname=\"activitypointer\">scheduledstart</column><column width=\"140\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Due&#32;Date\" fieldname=\"scheduledend\" entityname=\"activitypointer\">scheduledend</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Primary&#32;Email&#32;&#40;Owning&#32;User&#41;\" fieldname=\"internalemailaddress\" entityname=\"systemuser\" relationshipname=\"user_activity\">activitypointerowningusersystemusersystemuserid.internalemail"
		"address</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Date&#32;Created\" fieldname=\"createdon\" entityname=\"activitypointer\">createdon</column><column width=\"0\" isHidden=\"true\" isMetadataBound=\"true\" isSortable=\"false\" label=\"Recurring&#32;Instance&#32;Type\" fieldname=\"instancetypecode\" entityname=\"activitypointer\">instancetypecode</column><column width=\"0\" isHidden=\"true\" isMetadataBound=\"true\" isSortable=\"false\" label=\"Social&#32;Channel\" fieldname=\"community\" entityname=\"activitypointer\">community</column></columns></grid></gridRequest></gridMultiRequest>",
		LAST);

	lr_save_string(lr_eval_string("{CorrelationParameter_2131}"), "path2");

	crmwrpctokencase();
	
	web_add_header("CRMWRPCToken", 
	               lr_eval_string("{path2}"));

	web_add_header("CRMWRPCTokenTimeStamp", 
		"{CorrelationParameter_2130}");

	web_add_header("Cache-Control", 
		"no-cache");

	web_add_header("ReferrerReqId",
		"{CorrelationParameter_2127}");

	web_custom_request("AppGridWebService.ashx_9",
		"URL=https://{param_URL}/AppWebServices/AppGridWebService.ashx?operation=Refresh",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://{param_URL}/form/page.aspx?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&{lcid1}&themeId={themeID}&tstamp={tstamp}&updateTimeStamp={updateTimeStamp}&userts={userts}&ver=385312038",
		"Snapshot=t263.inf",
		"Mode=HTML",
		"EncType=text/plain;charset=UTF-8",
		"Body=<grid><sortColumns>createdon&#58;0&#59;dhhs_subject&#58;1</sortColumns><pageNum>1</pageNum><recsPerPage>10</recsPerPage><dataProvider>Microsoft.Crm.Application.Platform.Grid.GridDataProviderQueryBuilder</dataProvider><uiProvider>Microsoft.Crm.Application.Controls.GridUIProvider</uiProvider><cols/><max>1</max><refreshAsync>True</refreshAsync><pagingCookie/><enableMultiSort>true</enableMultiSort><enablePagingWhenOnePage>true</enablePagingWhenOnePage><refreshCalledFromRefreshButton>1</refreshCalledFromRefreshButton><returntotalrecordcount>true</returntotalrecordcount><getParameters></getParameters><parameters><viewid>&#123;A0F0F688-932C-E811-A832-000D3AE09197&#125;</viewid><RenderAsync>0</RenderAsync><LoadOnDemand>1</LoadOnDemand><autorefresh>1</autorefresh><isGridHidden>false</isGridHidden><LayoutStyle>LiteGridList</LayoutStyle><maxselectableitems>1</maxselectableitems><isGridFilteringEnabled>1</isGridFilteringEnabled><viewtype>1039</viewtype><viewts>4796774</viewts><RecordsPerPage>10</RecordsPerPage><vie"
		"wTitle>CaseActivities_For_Professional_Person</viewTitle><layoutXml>&#60;grid name&#61;&#34;resultset&#34; jump&#61;&#34;dhhs_name&#34; select&#61;&#34;1&#34; icon&#61;&#34;1&#34; preview&#61;&#34;1&#34; object&#61;&#34;10216&#34;&#62;&#60;row name&#61;&#34;result&#34; id&#61;&#34;dhhs_caseactivityid&#34;&#62;&#60;cell name&#61;&#34;dhhs_activitylink&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_category&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;createdon&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_actualstart&#34; width&#61;&#34;150&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_activitytype&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_subject&#34; width&#61;&#34;200&#34; imageproviderfunctionname&#61;&#34;&#34; imagepro"
		"viderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;cell name&#61;&#34;ownerid&#34; width&#61;&#34;100&#34; &#47;&#62;&#60;cell name&#61;&#34;dhhs_statusreasontext&#34; width&#61;&#34;125&#34; imageproviderfunctionname&#61;&#34;&#34; imageproviderwebresource&#61;&#34;&#36;webresource&#58;&#34; &#47;&#62;&#60;&#47;row&#62;&#60;&#47;grid&#62;</layoutXml><otc>10216</otc><otn>dhhs_caseactivity</otn><entitydisplayname>Case Activity</entitydisplayname><titleformat>&#123;0&#125; &#123;1&#125;</titleformat><entitypluraldisplayname>Case Activities</entitypluraldisplayname><expandable>1</expandable><showjumpbar>0</showjumpbar><maxrowsbeforescroll>12</maxrowsbeforescroll><tabindex>2650</tabindex><refreshasynchronous>1</refreshasynchronous><subgridAutoExpand>0</subgridAutoExpand><relName>dhhs_contact_dhhs_caseactivity_PersonId</relName><roleOrd>-1</roleOrd><oType>2</oType><relationshipType>1</relationshipType><ribbonContext>SubGridStandard</ribbonContext><GridType>SubGrid</GridType><enableContextualActi"
		"ons>true</enableContextualActions><teamTemplateId></teamTemplateId><isWorkflowSupported>true</isWorkflowSupported><LoadOnDemand_GridEmptyMessage>To load &#123;0&#125; records, click here.</LoadOnDemand_GridEmptyMessage><enableFilters></enableFilters><InnerGridDisabled>0</InnerGridDisabled><oId>&#123;{oId_1}&#125;</oId><effectiveFetchXml>&#60;fetch distinct&#61;&#34;false&#34; no-lock&#61;&#34;false&#34; mapping&#61;&#34;logical&#34; page&#61;&#34;1&#34; count&#61;&#34;10&#34; returntotalrecordcount&#61;&#34;true&#34;&#62;&#60;entity name&#61;&#34;dhhs_caseactivity&#34;&#62;&#60;attribute name&#61;&#34;createdon&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_subject&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_category&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_actualstart&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_activitytype&#34; &#47;&#62;&#60;attribute name&#61;&#34;ownerid&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_activitylink&#34; &#47;&#62;&#60;at"
		"tribute name&#61;&#34;dhhs_statusreasontext&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_caseactivityid&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_activitylink&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_category&#34; &#47;&#62;&#60;attribute name&#61;&#34;createdon&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_actualstart&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_activitytype&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_subject&#34; &#47;&#62;&#60;attribute name&#61;&#34;ownerid&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_statusreasontext&#34; &#47;&#62;&#60;filter type&#61;&#34;and&#34;&#62;&#60;condition attribute&#61;&#34;statecode&#34; operator&#61;&#34;eq&#34; value&#61;&#34;0&#34; &#47;&#62;&#60;condition attribute&#61;&#34;dhhs_personid&#34; operator&#61;&#34;eq&#34; value&#61;&#34;&#123;{oId_1}&#125;&#34; &#47;&#62;&#60;&#47;filter&#62;&#60;order attribute&#61;&#34;createdon&#34; descending&#61;&#34;true&#34; &#47;&#62;&#60;order attrib"
		"ute&#61;&#34;dhhs_subject&#34; descending&#61;&#34;false&#34; &#47;&#62;&#60;&#47;entity&#62;&#60;&#47;fetch&#62;</effectiveFetchXml><isFetchXmlNotFinal>False</isFetchXmlNotFinal><fetchXmlForFilters>&#60;fetch version&#61;&#34;1.0&#34; mapping&#61;&#34;logical&#34;&#62;&#60;entity name&#61;&#34;dhhs_caseactivity&#34;&#62;&#60;attribute name&#61;&#34;createdon&#34; &#47;&#62;&#60;order attribute&#61;&#34;createdon&#34; descending&#61;&#34;true&#34; &#47;&#62;&#60;order attribute&#61;&#34;dhhs_subject&#34; descending&#61;&#34;false&#34; &#47;&#62;&#60;filter type&#61;&#34;and&#34;&#62;&#60;condition attribute&#61;&#34;statecode&#34; operator&#61;&#34;eq&#34; value&#61;&#34;0&#34; &#47;&#62;&#60;&#47;filter&#62;&#60;attribute name&#61;&#34;dhhs_subject&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_category&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_actualstart&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_activitytype&#34; &#47;&#62;&#60;attribute name&#61;&#34;ownerid&#34; &#47;&#62;&#60;attribute"
		" name&#61;&#34;dhhs_activitylink&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_statusreasontext&#34; &#47;&#62;&#60;attribute name&#61;&#34;dhhs_caseactivityid&#34; &#47;&#62;&#60;&#47;entity&#62;&#60;&#47;fetch&#62;</fetchXmlForFilters><isTurboForm>1</isTurboForm></parameters><columns><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;link\" fieldname=\"dhhs_activitylink\" entityname=\"dhhs_caseactivity\" type=\"String.url\" sourcetype=\"0\">dhhs_activitylink</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Category\" fieldname=\"dhhs_category\" entityname=\"dhhs_caseactivity\" type=\"String.text\" sourcetype=\"0\">dhhs_category</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Created&#32;On\" fieldname=\"createdon\" entityname=\"dhhs_caseactivity\" imageproviderwebresource=\"&#36;webresource&#58;\" type=\"DateTime.datetime\" sourcetype=\"0\">c"
		"reatedon</column><column width=\"150\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Actual&#32;start\" fieldname=\"dhhs_actualstart\" entityname=\"dhhs_caseactivity\" imageproviderwebresource=\"&#36;webresource&#58;\" type=\"DateTime.datetime\" sourcetype=\"0\">dhhs_actualstart</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;type\" fieldname=\"dhhs_activitytype\" entityname=\"dhhs_caseactivity\" type=\"String.text\" sourcetype=\"0\">dhhs_activitytype</column><column width=\"200\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Subject\" fieldname=\"dhhs_subject\" entityname=\"dhhs_caseactivity\" imageproviderwebresource=\"&#36;webresource&#58;\" type=\"String.text\" sourcetype=\"0\">dhhs_subject</column><column width=\"100\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Owner\" fieldname=\"ownerid\" entityname=\"dhhs_caseactivity\" type=\"Owner\" sourcetype=\"0\">ow"
		"nerid</column><column width=\"125\" isHidden=\"false\" isMetadataBound=\"true\" isSortable=\"true\" label=\"Activity&#32;status\" fieldname=\"dhhs_statusreasontext\" entityname=\"dhhs_caseactivity\" imageproviderwebresource=\"&#36;webresource&#58;\" type=\"String.text\" sourcetype=\"0\">dhhs_statusreasontext</column></columns></grid>",
		LAST);

	lr_end_transaction("CRM_01_PersonSearch_06_OpenPerson",LR_AUTO);

	lr_think_time(5);

	web_add_auto_header("Accept", 
		"text/html, application/xhtml+xml, */*");

	web_add_auto_header("Accept-Encoding", 
		"gzip, deflate, peerdist");

	web_add_header("X-P2P-PeerDist", 
		"Version=1.1");

	web_add_header("X-P2P-PeerDistEx", 
		"MinContentInformation=1.0, MaxContentInformation=2.0");

	lr_start_transaction("CRM_01_PersonSearch_07_PersonSearch");

	web_url("dhhs_ElasticSearch.html_2", 
		"URL=https://{param_URL}/%7B636557150610000510%7D/WebResources/dhhs_ElasticSearch.html?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&pagemode=iframe&sitemappath=area_service%7cPeople%7cNewSubArea_37de7593", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{param_URL}/main.aspx?appid=ab18c93f-61e6-e711-a848-000d3ad117e3", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		LAST);

/*Correlation comment - Do not change!  Original value='462d2695-18e7-484b-83e9-3af296a53985' Name ='CorrelationParameter_2126' Type ='ResponseBased'*/
	web_reg_save_param_json(
		"ParamName=CorrelationParameter_2128",
		"QueryString=$.value[0].dhhs_azuresearchkey",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_custom_request("dhhs_systemsettings", 
		"URL=https://{param_URL}/api/data/v9.0/dhhs_systemsettings?$select=dhhs_azuresearchkey,dhhs_azuresearchurl,dhhs_d365url,dhhs_hublinkappid", 
		"Method=GET", 
		"Resource=1", 
		"RecContentType=application/json", 
		"Referer=https://{param_URL}/%7B636557150610000510%7D/WebResources/dhhs_ElasticSearch.html?appid=ab18c93f-61e6-e711-a848-000d3ad117e3&pagemode=iframe&sitemappath=area_service%7cPeople%7cNewSubArea_37de7593", 
		"Snapshot=t221.inf", 
		"EncType=application/json", 
		LAST);

	lr_end_transaction("CRM_01_PersonSearch_07_PersonSearch",LR_AUTO);

	return 0;
}