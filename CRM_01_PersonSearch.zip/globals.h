#ifndef _GLOBALS_H 
#define _GLOBALS_H

//--------------------------------------------------------------------
// Include Files
#include "lrun.h"
#include "web_api.h"
#include "lrw_custom_body.h"
#include "CRM_Login_Popup.c"
#include "CRM_LoginReport.c"
#include "CRM_Logout.c"
#include "crmwrpctoken.h"
#include "crmwrpctokencase.h"

//--------------------------------------------------------------------
// Global Variables

long cf1;
char *DHHS="param_PersonNumber1.dat";

/*#include <string.h>
char path1[1024],path2[1024],path3[1024];
char separators[] = "\\"; 
char * token,* token1,* pch;
char word[] = "x2b";
char crmwrpctoken1[1024],crmwrpctoken2[1024],crmwrpctoken3[1024],crmwrpctoken4[1024];*/

#endif // _GLOBALS_H
